﻿CLF-UoClassicフォント
	Copyright(c) 2018 uo.clife.work
	Copyright(c) Information-technology Promotion Agency, Japan (IPA), 2003-2011.



概要
----

CLF-UoClassicフォントは、
Ultima Online（ (C) Electronic Arts Inc. ）の
2Dクライアント風の半角英数字と一部記号の文字アウトラインを制作し、
その他の文字をIPAexゴシックで補ったTrueTypeフォントです。



ライセンス
----------

このフォントのライセンスは、
IPAフォントのライセンスに準じます。

IPAフォントのライセンスは、配布物に含まれる
IPA_Font_License_Agreement_v1.0.txt
をご覧ください。

このフォントをIPAフォントに置き換える場合は、
以下のWebサイトで「IPAexゴシック」を
入手してください。
http://ossipedia.ipa.go.jp/ipafont/

派生プログラム（CLF-UoClassicフォント）を作成する過程で
フォント開発プログラム（FontForge）によって作成された追加のファイルであって
派生プログラムをさらに加工するにあたって利用できるファイル（*.sfdファイル）
は、以下のURLから入手できます。
https://github.com/uo-clife-work/CLF-UoClassic-Font/tree/master/src




-- 
uo.clife.work
https://uo.clife.work/
