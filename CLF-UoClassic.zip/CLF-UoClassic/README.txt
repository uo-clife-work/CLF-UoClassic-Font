﻿CLF-UoClassicフォント
Version 1.1
	Copyright(c) 2018 uo.clife.work (https://uo.clife.work/)

	[Source Han Sans]
	Copyright (c) 2014, 2015 Adobe Systems Incorporated (http://www.adobe.com/), with Reserved Font Name 'Source'.

	[M+ OUTLINE FONTS]
	Copyright(c) 2015 M+ FONTS PROJECT



このフォントの概要
------------------

CLF-UoClassicフォントは、
Ultima Online（ (C) Electronic Arts Inc. ）の
2Dクライアント風の半角英数字と一部記号の文字アウトラインを制作し、
その他の文字を 「Mgen+ (ムゲンプラス) 2cp medium (http://jikasei.me/font/mgenplus/) 」を
若干変更した物で補ったTrueTypeフォントです。

Ultima OnlineのSAクライアント（Ultima Online Enhanced Client）での
テキスト表示用として制作しました。（デザイン用途などには厳しいと思います）



ライセンス
----------

このフォントのライセンス、SIL Open Font License 1.1 の内容は、アーカイブに同梱の LICENSE.txt に記載されています。
日本語訳は、以下から参照することができます。
http://osdn.jp/projects/opensource/wiki/SIL_Open_Font_License_1.1



-- 
uo.clife.work
https://uo.clife.work/
